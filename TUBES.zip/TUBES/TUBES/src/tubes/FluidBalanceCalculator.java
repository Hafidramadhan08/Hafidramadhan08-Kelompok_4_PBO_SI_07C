package tubes;

public class FluidBalanceCalculator extends BaseCalculator {
    private final float infus; // Infus (ml)
    private float airMinum; // Air Minum (ml)
    private float sariMakanan; // Sari Makanan (ml)
    private float muntah; // Muntah (ml)
    private float urin; // Urin (ml)
    private float feses; // Feses (ml)

    public FluidBalanceCalculator(float beratBadan, float suhu, float infus, 
                                  float airMinum, float sariMakanan, float muntah, 
                                  float urin, float feses) {
        super(beratBadan, suhu);
        this.infus = infus;
        this.airMinum = airMinum;
        this.sariMakanan = sariMakanan;
        this.muntah = muntah;
        this.urin = urin;
        this.feses = feses;
    }

    @Override
    public float calculate() {
        if (!validateInputs()) return 0;
        float intake = infus + airMinum + sariMakanan;
        float output = muntah + urin + feses;
        return intake - output;
    }
}