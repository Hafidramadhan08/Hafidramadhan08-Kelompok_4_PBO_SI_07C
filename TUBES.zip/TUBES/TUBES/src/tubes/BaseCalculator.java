package tubes;

abstract class BaseCalculator {
    protected float beratBadan;
    protected float suhu;

    // Konstruktor menggunakan tipe data float
    public BaseCalculator(float beratBadan, float suhu) {
        this.beratBadan = beratBadan;
        this.suhu = suhu;
    }

    // Method abstrak untuk perhitungan
    public abstract float calculate();

    // Validasi input
    protected boolean validateInputs() {
        return beratBadan > 0 && suhu > 0;
    }
}
