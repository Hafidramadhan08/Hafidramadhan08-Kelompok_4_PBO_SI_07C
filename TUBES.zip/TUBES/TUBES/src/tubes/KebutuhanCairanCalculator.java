package tubes;

public class KebutuhanCairanCalculator {

    private int umur;
    private float suhu;
    private float beratBadan;

    public KebutuhanCairanCalculator(int umur, float suhu, float beratBadan) {
        this.umur = umur;
        this.suhu = suhu;
        this.beratBadan = beratBadan;
    }

    public float calculate() {
        if (suhu > 100) {
            suhu = suhu / 10.0f; // Mengonversi suhu jika lebih dari 100
        }

        int[] konsUmur = {40, 35, 30, 25};
        float hasilKonsUmur;

        if (umur >= 16 && umur <= 30) {
            hasilKonsUmur = konsUmur[0];
        } else if (umur >= 31 && umur <= 55) {
            hasilKonsUmur = konsUmur[1];
        } else if (umur >= 56 && umur <= 75) {
            hasilKonsUmur = konsUmur[2];
        } else if (umur >= 76) {
            hasilKonsUmur = konsUmur[3];
        } else {
            hasilKonsUmur = konsUmur[0];
        }

        float hasilKC = beratBadan * hasilKonsUmur;
        if (suhu > 37.5) {
            float konsNaik = hasilKC * (Math.abs(suhu - 37.5f) * 0.06f);
            hasilKC += konsNaik;
        }

        return hasilKC;
    }
}
